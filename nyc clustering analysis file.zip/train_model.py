import pandas as pd
from sklearn.cluster import KMeans
import pickle
from preprocessing import preprocess_data

def main():
    print("Training started...")

    # Load data
    df = pd.read_csv("sample_data.csv")

    # Preprocess
    X_scaled, df_enriched = preprocess_data(df)

    # Train model
    kmeans = KMeans(n_clusters=2, random_state=42)  # Change to 2 clusters
    kmeans.fit(X_scaled)

    # Save model
    with open("model.pkl", "wb") as f:
        pickle.dump(kmeans, f)

    print("✅ Training complete. Model saved to 'model.pkl'.")

if __name__ == "__main__":
    main()
